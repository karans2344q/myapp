import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useCart } from './CartContext';
import {
  FiShoppingCart,
  FiArrowLeft,
  FiTruck,
  FiStar,
  FiShare2,
  FiHeart,
} from 'react-icons/fi';
import './ProductDetail.css';

function ProductDetail() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const { addToCart } = useCart();

  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState('');

  if (!state?.product) {
    return (
      <div className="not-found-container">
        <div className="not-found-content">
          <h2>Oops! Product Not Found</h2>
          <p>The product you're looking for doesn't exist or may have been removed.</p>
          <button className="back-home-btn" onClick={() => navigate('/')}>
            <FiArrowLeft /> Back to Home
          </button>
        </div>
      </div>
    );
  }

  const { name, img, price, images = [img] } = state.product;
  const category = state.category;

  const handleAddToCart = () => {
    const priceValue = parseInt(price.replace("₹", ""));
    addToCart({
      name,
      image: img,
      price: priceValue,
      quantity
    });

    document.querySelector('.add-to-cart-toast').classList.add('show');
    setTimeout(() => {
      document.querySelector('.add-to-cart-toast').classList.remove('show');
    }, 3000);
  };

  const handleBuyNow = () => {
    const priceValue = parseInt(price.replace("₹", ""));
    const buyItem = {
      name,
      image: img,
      price: priceValue,
      quantity
    };
    navigate("/checkout", { state: { buyNowItem: buyItem } });
  };

  const categoryDetails = {
    men: {
      label: "Men's Premium",
      description: "Engineered for the modern gentleman with premium material and classic style.",
      color: "#3b82f6",
      bgColor: "#dbeafe"
    },
    women: {
      label: "Women's Elegant",
      description: "Gracefully crafted for today's woman, with timeless elegance and comfort.",
      color: "#ec4899",
      bgColor: "#fce7f3"
    },
    kids: {
      label: "Kids' Collection",
      description: "Fun and safe products for your little ones—made for imagination and play.",
      color: "#10b981",
      bgColor: "#d1fae5"
    },
    default: {
      label: "Featured",
      description: "Premium design, built for everyday excellence.",
      color: "#8b5cf6",
      bgColor: "#ede9fe"
    }
  };

  const currentCategory = categoryDetails[category] || categoryDetails.default;

  const handleReviewSubmit = () => {
    if (newReview.trim()) {
      setReviews([...reviews, newReview]);
      setNewReview('');
    }
  };

  return (
    <div className="product-detail-page">
      {/* Toast Notification */}
      <div className="add-to-cart-toast">
        <div className="toast-content">
          <FiShoppingCart /> Added to cart successfully!
        </div>
      </div>

      <div className="product-detail-container">
        {/* Image Gallery */}
        <div className="product-gallery">
          <div className="thumbnail-container">
            {images.map((image, index) => (
              <div
                key={index}
                className={`thumbnail ${selectedImage === index ? 'active' : ''}`}
                onClick={() => setSelectedImage(index)}
              >
                <img src={image} alt={`${name} thumbnail ${index}`} />
              </div>
            ))}
          </div>
          <div className="main-image-container">
            <img
              src={images[selectedImage]}
              alt={name}
              className="main-product-image"
            />
            <div className="image-actions">
              <button className="action-btn wishlist">
                <FiHeart /> Wishlist
              </button>
              <button className="action-btn share">
                <FiShare2 /> Share
              </button>
            </div>
          </div>
        </div>

        {/* Product Info */}
        <div className="product-info-section">
          <div
            className="category-tag"
            style={{
              backgroundColor: currentCategory.bgColor,
              color: currentCategory.color
            }}
          >
            {currentCategory.label}
          </div>

          <h1 className="product-title">{name}</h1>

          <div className="rating-container">
            <div className="stars">
              {[...Array(5)].map((_, i) => (
                <FiStar key={i} className={i < 4 ? 'filled' : ''} />
              ))}
            </div>
            <span className="review-count">({reviews.length + 42} reviews)</span>
          </div>

          <div className="price-container">
            <span className="current-price">{price}</span>
            {price.includes('₹') && (
              <span className="original-price">
                ₹{parseInt(price.replace('₹', '')) + 999}
              </span>
            )}
            <span className="discount-badge">25% OFF</span>
          </div>

          <div className="shipping-info">
            <FiTruck className="truck-icon" />
            <span>
              Free delivery on orders over ₹999. Order now and get it by tomorrow!
            </span>
          </div>

          <p className="product-description">{currentCategory.description}</p>

          <div className="product-highlights">
            <h3>Product Highlights</h3>
            <ul>
              <li>Premium quality materials</li>
              <li>Designed for comfort and style</li>
              <li>Easy to maintain and clean</li>
              <li>1 year manufacturer warranty</li>
            </ul>
          </div>

          <div className="quantity-selector">
            <label>Quantity:</label>
            <div className="quantity-controls">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
              >
                −
              </button>
              <span>{quantity}</span>
              <button onClick={() => setQuantity(quantity + 1)}>+</button>
            </div>
          </div>

          <div className="action-buttons">
            <button className="add-to-cart-btn" onClick={handleAddToCart}>
              <FiShoppingCart /> Add to Cart
            </button>
            <button className="buy-now-btn" onClick={handleBuyNow}>
              Buy Now
            </button>
          </div>

          <button className="back-to-shop" onClick={() => navigate(-1)}>
            <FiArrowLeft /> Continue Shopping
          </button>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="review-section">
        <h3>Customer Reviews</h3>
        {reviews.length === 0 ? (
          <p>No reviews yet. Be the first to review!</p>
        ) : (
          <ul className="review-list">
            {reviews.map((r, i) => (
              <li key={i} className="review-item">⭐ {r}</li>
            ))}
          </ul>
        )}
        <div className="add-review">
          <textarea
            placeholder="Write your review..."
            value={newReview}
            onChange={(e) => setNewReview(e.target.value)}
          />
          <button onClick={handleReviewSubmit}>Submit Review</button>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;
