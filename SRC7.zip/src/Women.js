

 import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Women.css';

function Women() {
  const navigate = useNavigate();
 


    const products = [
        {
            img: "https://modamello.com/wp-content/uploads/2024/06/image-7.png",
            name: "Elegant Red Dress",
            price: "₹1499"
        },
        {
            img: "https://m.media-amazon.com/images/I/61qDaOZzfKL._UY1100_.jpg",
            name: "Trendy Sunglasses",
            price: "₹499"
        },
        {
            img: "https://www.fastrack.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw5682a19a/images/Fastrack/Catalog/F24SSALAV07TN1_9.jpg?sw=600&sh=600",
            name: "Classic Handbag",
            price: "₹1999"
        },
        {
            img: "https://www.jiomart.com/images/product/original/rvib7nop19/moomaya-sleeveless-peplum-strappy-top-printed-cotton-tank-top-summer-tops-product-images-rvib7nop19-0-202308191602.jpg?im=Resize=(500,630)",
            name: "Summer Top",
            price: "₹799"
        },
        {
            img: "https://uspoloassn.in/cdn/shop/products/1_03199a04-5ce3-4558-b074-453da8f597dd.jpg",
            name: "Blue Jeans",
            price: "₹1199"
        },
        {
            img: "https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/29068106/2024/10/8/f69a46bd-e13a-44b0-bc9f-90d27d9cc05c1728369194574-her-by-invictus-Women-Blazers-5971728369193898-1.jpg",
            name: "Formal Blazer",
            price: "₹2499"
        },
        {
            img: "https://m.media-amazon.com/images/I/91YKqR+X9NL._UY1100_.jpg",
            name: "Printed Kurti",
            price: "₹999"
        },
        {
            img: "https://m.media-amazon.com/images/I/71IS4-USxcL._UY1000_.jpg",
            name: "Stylish Heels",
            price: "₹1299"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHTp0zcs7FeUryhuHFplDpRSLkVZgpuxrzdA&s",
            name: "Party Gown",
            price: "₹2999"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnZHg7X77a7bgy7r46hwZ8bL6JYkIxpveY1A&s",
            name: "Ethnic Saree",
            price: "₹1899"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTLSOPZnyk-r9ec6ZfKqniFrAPorD6RYy6iVQ&s",
            name: "Designer Dupatta",
            price: "₹599"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfUtrjUPEZ1d8J7hpsxO3BS-tcByy8xJ0B9A&s",
            name: "Casual T-shirt",
            price: "₹499"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjH9kIpLTDcRNvW3I8gVS_j6IITTShpX4b2A&s",
            name: "Trendy Skirt",
            price: "₹899"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQt98PEOHoJKbUXsUsTDtiR1A-i3eqXY9Z6Jw&s",
            name: "Fashion Earrings",
            price: "₹299"
        },
        {
            img: "https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/23644542/2023/9/11/8867041d-b83e-41b9-95ff-006aac3a0e9e1694436803504DENNISONWomenSolidSlimFitSingleBreasted2-PieceFormalSuit1.jpg",
            name: "Formal Suit",
            price: "₹3499"
        },
        {
            img: "https://assets.ajio.com/medias/sys_master/root/20231016/L6FL/652c5051afa4cf41f5466bdf/-473Wx593H-466711316-blue-MODEL.jpg",
            name: "Printed Dress",
            price: "₹1099"
        },
        {
            img: "https://www.aroundalways.com/cdn/shop/files/HopeSandals2.jpg?v=1748329397",
            name: "Stylish Sandals",
            price: "₹799"
        },
        {
            img: "https://africanboutique.in/wp-content/uploads/2022/01/CS-0828-1-scaled-1.jpg",
            name: "Evening Gown",
            price: "₹2599"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTeWKMzQl75EtxTgVObY0-qjvppkxLgWXxHGQ&s",
            name: "Designer Lehenga",
            price: "₹3999"
        },
        {
            img: "https://mahezon.in/cdn/shop/files/IMG-20240513_202034_310.jpg?v=1715612319",
            name: "Red Saree",
            price: "₹1599"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJwRmU9xe32YY9ySLf0GF2GgMmZMAfrzadmQ&s",
            name: "Boho Necklace",
            price: "₹349"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9GUko-RD-xCpn51OWN4Q_JzI2xSoOsEeJsw&s",
            name: "Denim Jacket",
            price: "₹1599"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR28otrcmyM2tvO64NyYZRYQgDEIX_84cd-AQ&s",
            name: "Crop Hoodie",
            price: "₹999"
        },
        {
            img: "https://images.meesho.com/images/products/425939205/idxuq_512.webp",
            name: "Hair Accessories Set",
            price: "₹299"
        },
        {
            img: "https://www.jiomart.com/images/product/original/rvqthd4tap/popwings-single-button-closure-women-black-shrug-shrugs-for-women-latest-solid-design-shrugs-women-stylish-shrugs-regular-shrugs-product-images-rvqthd4tap-1-202310181807.jpg?im=Resize=(500,630)",
            name: "Western Jumpsuit",
            price: "₹1399"
        },
        {
            img: "https://www.stylemantraas.com/wp-content/uploads/2021/12/3a8a5d5c-87c4-4afb-aec3-7e95b5d029a5-410x410.jpg",
            name: "Black Shrug",
            price: "₹649"
        },
        {
            img: "https://4.bp.blogspot.com/-g9nebrbgW2c/VtyO2RhdpOI/AAAAAAAAWqo/iX6Knftb1SA/s0/Jolie%2BMoi%2Bflorl%2Bskirt.JPG",
            name: "Floral Midi Skirt",
            price: "₹999"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnBqRFRv0O_8TCPiJNGgS9bcu4pFoDqEmC9A&s",
            name: "Traditional Suit Set",
            price: "₹2299"
        },
        {
            img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTP5S3LrumYmIJqNQV_qLqxJBLVXVkzjVRKw&s",
            name: "Festive Kurti",
            price: "₹1199"
        },
        {
            img: "https://m.media-amazon.com/images/I/21fmoZVJ9gL.AC_SR175,263_QL70.jpg",
            name: "Office Wear Combo",
            price: "₹2899"
        },
        {
            img: "https://img.kwcdn.com/product/fancy/2464ad07-96f7-4809-9074-477b206c64aa.jpg?imageView2/2/w/500/q/60/format/webp",
            name: "Yellow Handbag",
            price: "₹899"
        }
      ];




  const goToDetails = (product, index) => {
    navigate(`/product/${index}`, {
      state: { product, category: 'women' }
    });
  };

  return (
    <div className="women-section">
      <h1>Women Section</h1>
      <div className="women-gallery">
        {products.map((item, idx) => (
          <div
            className="women-card"
            key={idx}
            onClick={() => goToDetails(item, idx)}
            style={{ cursor: 'pointer' }}
          >
            <img src={item.img} alt={item.name} className="women-img" />
            <div className="women-details">
              <h3>{item.name}</h3>
              <p className="women-price">{item.price}</p>
              <button className="cart-btn">View Details</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Women;
