import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useCart } from './CartContext';

function Navbar({ username, setUsername }) {
  const { cartCount } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("userData");
    setUsername();
    navigate('/login');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm sticky-top py-3">
      <div className="container">
        <NavLink className="navbar-brand fw-bold fs-4" to="/">
          🛍️ MYSHOP
        </NavLink>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto align-items-center gap-3">

            {/* HOME */}
            <li className="nav-item">
              <NavLink className="nav-link" to="/">
                <i className="fas fa-home me-1"></i> Home
              </NavLink>
            </li>

            {/* LOGIN + REGISTER if not logged in */}
            {!username && (
              <>
                <li className="nav-item">
                  <NavLink className="nav-link" to="/login">
                    <i className="fas fa-sign-in-alt me-1"></i> Login
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className="nav-link" to="/register">
                    <i className="fas fa-user-plus me-1"></i> Register
                  </NavLink>
                </li>
              </>
            )}

            {/* MEN */}
            <li className="nav-item">
              <NavLink className="nav-link" to="/men">
                <i className="fas fa-male me-1"></i> Men
              </NavLink>
            </li>

            {/* WOMEN */}
            <li className="nav-item">
              <NavLink className="nav-link" to="/women">
                <i className="fas fa-female me-1"></i> Women
              </NavLink>
            </li>

            {/* KIDS */}
            <li className="nav-item">
              <NavLink className="nav-link" to="/kids">
                <i className="fas fa-child me-1"></i> Kids
              </NavLink>
            </li>

            {/* ABOUT */}
            <li className="nav-item">
              <NavLink className="nav-link" to="/about">
                <i className="fas fa-info-circle me-1"></i> About
              </NavLink>
            </li>

            {/* CONTACT */}
            <li className="nav-item">
              <NavLink className="nav-link" to="/contact">
                <i className="fas fa-envelope me-1"></i> Contact
              </NavLink>
            </li>

            {/* CART */}
            <li className="nav-item position-relative">
              <NavLink className="nav-link" to="/cart">
                <i className="fas fa-shopping-cart fs-5"></i>
                {cartCount > 0 && (
                  <span
                    className="position-absolute top-0 start-100 translate-middle badge rounded-pill"
                    style={{
                      background: 'linear-gradient(135deg, #ff6b6b, #ff8e8e)',
                      fontSize: '0.7rem',
                      color: '#fff'
                    }}
                  >
                    {cartCount}
                  </span>
                )}
              </NavLink>
            </li>

            {/* PROFILE, ORDERS, LOGOUT if logged in */}
            {username && (
              <>
                <li className="nav-item">
                  <span 
                    className="nav-link"
                    style={{ color: '#4CAF50', fontWeight: 'bold', cursor: 'pointer' }}
                    onClick={() => navigate('/profile')}
                  >
                    <i className="fas fa-user me-1"></i> Hi, {username}
                  </span>
                </li>

                <li className="nav-item">
                  <NavLink className="nav-link" to="/order">
                    <i className="fas fa-box me-1"></i> My Orders
                  </NavLink>
                </li>

                <li className="nav-item">
                  <button 
                    className="btn btn-outline-light btn-sm"
                    onClick={handleLogout}
                  >
                    <i className="fas fa-sign-out-alt me-1"></i> Logout
                  </button>
                </li>
              </>
            )}

          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
