import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from './CartContext';
import './Kids.css';

function Kids() {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [selectedPrice, setSelectedPrice] = useState('all');
  const [hoveredCard, setHoveredCard] = useState(null);


 const products = [
  {
    img: "https://staranddaisy.in/wp-content/uploads/2022/12/51RnmUGWpxL.jpg",
    name: "Toy Car - Red",
    price: "₹1450"
  },
  {
    img: "https://www.yourprint.in/new-admin-ajax.php?action=resize_outer_image&cfcache=all&url=med-s3/yP-mplace/Toys/YPB09BL58LJB_1.jpg&resizeTo=600",
    name: "Teddy Bear (Brown)",
    price: "₹1200"
  },
  {
    img: "https://staranddaisy.in/wp-content/uploads/2023/09/dr-mady-s-mini-doll-house-naivri-2_bf6c923a-9db8-4243-a9d2-574b4742b000.png",
    name: "Doll House Set",
    price: "₹1999"
  },
  {
    img: "https://images-cdn.ubuy.co.in/63519c5510a71043c87053b4-stjoyopy-88pcs-big-building-blocks-with.jpg",
    name: "Building Blocks",
    price: "₹999"
  },
  {
    img: "https://m.media-amazon.com/images/I/71K2ASj-1ML.jpg",
    name: "Remote Control Helicopter",
    price: "₹1550"
  },
  {
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRz-unLqnQjU3CstIc7HkYF8QbpVXqIfbBrrQ&s",
    name: "Kids Sports Shoes",
    price: "₹1300"
  },
  {
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuPVIw7EMMZFH8GH8UMWLR4KkXo4AZFasywQ&s",
    name: "Baby Walker with Music",
    price: "₹1850"
  },
  {
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFwIi0kFdIu_RtbxolrTztyG-ZYQkI63MTuw&s",
    name: "Kids Puzzle Set",
    price: "₹950"
  },
  {
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZAssk7nB4QZ7VIVQDfRa0A0KlbBl_pFVOaA&s",
    name: "Boys Cartoon T-Shirt",
    price: "₹599"
  },
  {
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS08OcPvfZF1JDe0Q6IRaJ2FByiqybAe75yDw&s",
    name: "Girls Party Dress",
    price: "₹2999"
  },
  {
    img: "https://5.imimg.com/data5/SELLER/Default/2023/1/SX/FN/TE/3310206/kids-winter-jacket-500x500.jpg",
    name: "Kids Winter Jacket",
    price: "₹1600"
  },
  {
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOmI1EJ0CL7Fery82Kr7gn3V14LM3bb9tzEw&s",
    name: "Toy Train Set",
    price: "₹750"
  },
   { img: "https://m.media-amazon.com/images/I/71imzfqxcJL.jpg", name: "Coloring Book", price: "₹199" },
  { img: "https://www.shutterstock.com/image-photo/vintage-tin-robot-toy-isolated-600nw-1206408244.jpg", name: "Toy Robot", price: "₹1299" },
  { img: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Transparante_kunststof_zuigfles_met_blauwe_dop_en_siliconen_speen%2C_antilekplaatje_en_schroefbevestiging%2C_objectnr_83556-A-E.JPG/1200px-Transparante_kunststof_zuigfles_met_blauwe_dop_en_siliconen_speen%2C_antilekplaatje_en_schroefbevestiging%2C_objectnr_83556-A-E.JPG", name: "Baby Bottle", price: "₹399" },
  { img: "https://m.media-amazon.com/images/I/610hTAmlFlL.jpg", name: "Bath Toy Set", price: "₹499" },
  { img: "https://m.media-amazon.com/images/I/51Gsna7DNvL.jpg", name: "Mini Slide", price: "₹1750" },
  { img: "https://m.media-amazon.com/images/I/31QFD2xXzfL.jpg", name: "Toy Guitar", price: "₹999" },
  { img: "https://genietravel.com/cdn/shop/files/Artboard2copy3_92ea62aa-208f-425c-92da-7aaf5e53374b_1500x.jpg?v=1737444868", name: "School Backpack", price: "₹890" },
  { img: "https://m.media-amazon.com/images/I/81NM3P-NoqL._UF894,1000_QL80_.jpg", name: "Kids Sunglasses", price: "₹299" },
  { img: "https://m.media-amazon.com/images/I/81d3MmAGQNL.jpg", name: "Drawing Kit", price: "₹499" },
  { img: "https://antling.in/cdn/shop/files/premium_cap_lavender_priamry_1.png?v=1729855160", name: "Baby Cap", price: "₹199" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSe9IBUBcK6aGFTmd7Yz7VcyIWehcYWzxK3iw&s", name: "Bubble Maker", price: "₹399" },
  { img: "https://toyshine.in/cdn/shop/products/RODEO_PINK_1.jpg?v=1675942697", name: "Scooter", price: "₹2200" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThKaAhz8pdn01-PN-sAUZUtlSPeC1tvTf1Fg&s", name: "Toy Camera", price: "₹699" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDhJ-Mlf_ytY34FhMpyPv7Lf13U437eFmhag&s", name: "Fancy Hat", price: "₹349" },
  { img: "https://m.media-amazon.com/images/I/61l6mlc0slL.jpg", name: "Musical Toy", price: "₹899" },
  { img: "https://m.media-amazon.com/images/I/71KwPy8BPiL.jpg", name: "Sports Ball", price: "₹750" },
  { img: "https://rukminim2.flixcart.com/image/850/1000/kwcfngw0/book/0/n/p/moral-story-book-illustrated-story-book-for-kids-1-original-imag9fnf6pcargfc.jpeg?q=90&crop=false", name: "Story Book", price: "₹299" },
  { img: "https://m.media-amazon.com/images/I/41HkYHWoZZL._UF1000,1000_QL80_.jpg", name: "Cradle Toy", price: "₹649" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPoVEuVwYUPp3jHqkGDtSuUahgM8J3-hOKjg&s", name: "Birthday Cap", price: "₹129" },
  { img: "https://m.media-amazon.com/images/I/71+7zb2j2OL._UF1000,1000_QL80_.jpg", name: "Tricycle", price: "₹1799" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTg9Kfa0aQ07CBCOs0g9OXuyiYCdlhAAUVvFg&s", name: "Learning Tablet", price: "₹1349" },
  { img: "https://m.media-amazon.com/images/I/71lcJdGdlWL.jpg", name: "Toy Drum", price: "₹799" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3GDn2L7fIhgmzjlHog0UPz42uyIZ02A2iTA&s", name: "Cartoon Watch", price: "₹599" },
  { img: "https://m.media-amazon.com/images/I/716aM2QIXmS.jpg", name: "Action Figure", price: "₹1599" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHYWrTG1gbnxYGSZLQQZ0S6-nF6VnuVQu9UA&s", name: "Sand Toy Set", price: "₹499" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuZf3k6pu6Iwdh02rMBQgjTL4WwOURSeAWnA&s", name: "Water Gun", price: "₹399" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQceEKbotLfQkeZMnbxdFvZNvV_Y5GrTfGC7Q&s", name: "Sipper Bottle", price: "₹349" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEFyZvEX5mLvvrFln3Zn0sb4jnglGy7L3Vlw&s", name: "Magic Slate", price: "₹449" },
  { img: "https://m.media-amazon.com/images/I/61mHEtRZH9L.jpg", name: "Rattle Toy", price: "₹299" },
  { img: "https://www.thesprucecrafts.com/thmb/JKau-8-Kb7qgkXjYw5js6Ru3ijA=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/GettyImages-1016070420-895353d76aee4af79eef0104780ba20c.jpg", name: "Kite", price: "₹149" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPj9jvINT62-LToC3xIFti8b61Cf9j4M1CbA&s", name: "Swimming Tube", price: "₹599" },
  { img: "https://m.media-amazon.com/images/I/717MCdayvjL._UF1000,1000_QL80_.jpg", name: "Alphabet Blocks", price: "₹499" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRDVhgGcp7I7090eyWSIaw2G6MjiGUKaAZ6JQ&s", name: "Night Lamp", price: "₹899" },
  { img: "https://m.media-amazon.com/images/I/71cQmNhuARL._UF1000,1000_QL80_.jpg", name: "Soft Pillow", price: "₹499" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-lmGFl8xqi9EbctjSbutjzUtT0AeYmdWRPA&s", name: "Toy Binoculars", price: "₹550" },
  { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoPzlOGL3JwUIHEX1NP83O5gyqpMcCOQtLgQ&s", name: "Kids Tent", price: "₹1249" },
  { img: "https://m.media-amazon.com/images/I/61jr4rDBISL._UF894,1000_QL80_.jpg", name: "Wall Stickers", price: "₹349" },
  { img: "https://m.media-amazon.com/images/I/811Ynd0M1ML._UF1000,1000_QL80_.jpg", name: "Pop-up Book", price: "₹299" }
];



 
  const filterByPrice = (product) => {
    const price = parseInt(product.price.replace('₹', ''));
    switch (selectedPrice) {
      case 'below500': return price < 500;
      case '500to1000': return price >= 500 && price <= 1000;
      case '1000to2000': return price > 1000 && price <= 2000;
      case 'above2000': return price > 2000;
      default: return true;
    }
  };

  const goToDetails = (product, index) => {
    navigate(`/product/${index}`, {
      state: { product, category: 'kids' }
    });
  };

  const handleAddToCart = (e, item) => {
    e.stopPropagation(); // prevent card click
    const cleanedPrice = parseInt(item.price.replace('₹', ''));
    addToCart({ name: item.name, price: cleanedPrice, img: item.img });
    alert('✅ Item added to cart!');
  };

  const filteredProducts = products.filter(filterByPrice);

  return (
    <div className="kids-section">
      <div className="section-header">
        <h1 className="section-title">Kids Wonderland</h1>
        <p className="section-subtitle">Discover magical toys and essentials for your little ones</p>
      </div>

      <div className="filter-container">
        <div className="filter-bar">
          <label htmlFor="price-filter" className="filter-label">Filter by Price:</label>
          <select
            id="price-filter"
            value={selectedPrice}
            onChange={(e) => setSelectedPrice(e.target.value)}
            className="filter-dropdown"
          >
            <option value="all">All Prices</option>
            <option value="below500">Below ₹500</option>
            <option value="500to1000">₹500 - ₹1000</option>
            <option value="1000to2000">₹1000 - ₹2000</option>
            <option value="above2000">Above ₹2000</option>
          </select>
        </div>
        <div className="product-count">{filteredProducts.length} products found</div>
      </div>

      <div className="kids-gallery">
        {filteredProducts.map((item, idx) => (
          <div
            className={`kids-card ${hoveredCard === idx ? 'hovered' : ''}`}
            key={idx}
            onClick={() => goToDetails(item, idx)}
            onMouseEnter={() => setHoveredCard(idx)}
            onMouseLeave={() => setHoveredCard(null)}
          >
            <div className="card-image-container">
              <img src={item.img} alt={item.name} className="kids-img" />
              <div className="quick-view">Quick View</div>
            </div>
            <div className="kids-details">
              <h3>{item.name}</h3>
              <p className="kids-price">{item.price}</p>
              <div className="card-actions">
                <button className="cart-btn" onClick={(e) => handleAddToCart(e, item)}>
                  <span className="btn-icon">🛒</span>
                  <span className="btn-text">Add to Cart</span>
                </button>
                <button className="wishlist-btn">❤️</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Kids;
