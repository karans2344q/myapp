import React, { createContext, useContext, useEffect, useState } from 'react';
import { db, auth } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [userId, setUserId] = useState('guest');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      const uid = user?.uid || 'guest';
      setUserId(uid);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const fetchCart = async () => {
      if (!userId) return;
      const cartRef = doc(db, 'carts', userId);
      const docSnap = await getDoc(cartRef);
      if (docSnap.exists()) {
        setCartItems(docSnap.data()?.items || []);
      }
    };
    fetchCart();
  }, [userId]);

  const saveCartToFirebase = async (items) => {
    const cartRef = doc(db, 'carts', userId);
    await setDoc(cartRef, { items });
  };

  const addToCart = async (product) => {
    const productData = {
      name: product.name,
      price: typeof product.price === "string" ? parseInt(product.price.replace("₹", "")) : product.price,
      quantity: 1,
      image: product.img || product.image
    };

    setCartItems(prev => {
      const existing = prev.find(p => p.name === product.name);
      let updated;
      if (existing) {
        updated = prev.map(p =>
          p.name === product.name ? { ...p, quantity: p.quantity + 1 } : p
        );
      } else {
        updated = [...prev, productData];
      }
      saveCartToFirebase(updated);
      return updated;
    });
  };

  const updateQuantity = (name, quantity) => {
    if (quantity < 1) return;
    setCartItems(prev => {
      const updated = prev.map(item =>
        item.name === name ? { ...item, quantity } : item
      );
      saveCartToFirebase(updated);
      return updated;
    });
  };

  const removeFromCart = (name) => {
    setCartItems(prev => {
      const updated = prev.filter(item => item.name !== name);
      saveCartToFirebase(updated);
      return updated;
    });
  };

  const cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  return (
    <CartContext.Provider value={{ cartItems, addToCart, updateQuantity, removeFromCart, cartCount }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);